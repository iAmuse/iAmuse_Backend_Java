package com.iamuse.server.requestVO;

public class FileVO {

	private String file;

	public void setFile(String file) {
		this.file = file;
	}

	public String getFile() {
		return file;
	}

	
	
}
