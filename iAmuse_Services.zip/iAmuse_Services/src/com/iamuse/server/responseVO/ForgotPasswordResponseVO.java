package com.iamuse.server.responseVO;

import org.springframework.stereotype.Component;

@Component
public class ForgotPasswordResponseVO extends BaseResponseVO {

}
