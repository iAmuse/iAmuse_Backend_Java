package com.iamuse.admin.VO;

public class DeviceVO {
	private String cameraDeviceToken;
	private String touchDeviceToken;
	private String cameraDeviceIP;
	private String touchDeviceIP;
	public String getCameraDeviceToken() {
		return cameraDeviceToken;
	}
	public void setCameraDeviceToken(String cameraDeviceToken) {
		this.cameraDeviceToken = cameraDeviceToken;
	}
	public String getTouchDeviceToken() {
		return touchDeviceToken;
	}
	public void setTouchDeviceToken(String touchDeviceToken) {
		this.touchDeviceToken = touchDeviceToken;
	}
	public String getCameraDeviceIP() {
		return cameraDeviceIP;
	}
	public void setCameraDeviceIP(String cameraDeviceIP) {
		this.cameraDeviceIP = cameraDeviceIP;
	}
	public String getTouchDeviceIP() {
		return touchDeviceIP;
	}
	public void setTouchDeviceIP(String touchDeviceIP) {
		this.touchDeviceIP = touchDeviceIP;
	}
	
	
	
}
