package com.iamuse.admin.VO;

public class FileVO {

	private String file;

	public void setFile(String file) {
		this.file = file;
	}

	public String getFile() {
		return file;
	}

	
	
}
