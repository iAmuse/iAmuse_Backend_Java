package com.iamuse.admin.VO;

public class PaymentGateways {
	private String payment_gateway;

	public String getPayment_gateway() {
		return payment_gateway;
	}

	public void setPayment_gateway(String payment_gateway) {
		this.payment_gateway = payment_gateway;
	}
}
