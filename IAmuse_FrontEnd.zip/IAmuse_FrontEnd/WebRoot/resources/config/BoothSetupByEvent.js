
$( document ).ready(function() {
	 var x = document.getElementById("imgNatural").naturalWidth;
   	 var x1 = document.getElementById("imgNatural").naturalHeight;
     document.getElementById("imgNaturalWidth").value = x;
     document.getElementById("imgNaturalHeight").value = x1;
 	});



$(document).ready(function() {
	 $('#effect').delay(5000).fadeOut(400);
    $("#e").addClass("active_menu");
});
